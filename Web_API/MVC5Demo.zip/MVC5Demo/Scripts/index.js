﻿const appKey = "f24f40b1c24505685fce3b8acd0fcffc";
let searchButton = "";
let searchInput = "";
let cityName = "";
let icon = "";
let temperature = "";
let humidity = "";

$(document).ready(function () {
     searchButton = document.getElementById("search-btn");
     searchInput = document.getElementById("search-txt");
     cityName = document.getElementById("city-name");
     icon = document.getElementById("icon");
     temperature = document.getElementById("temp");
     humidity = document.getElementById("humidity-div");
    alert(searchButton.id);
    searchButton.addEventListener("click", findWeatherDetails);
    searchInput.addEventListener("keyup", enterPressed);
});
function enterPressed(event) {
    if (event.key === "Enter") {
        alert("enter" + searchInput.value);
        GetLatLong(searchInput.value);
        findWeatherDetails();
    }
}

function findWeatherDetails() {
   
    if (searchInput.value === "") {

    } else {

        let searchLink = "http://localhost/WeatherForcast.API/api/Values/?lat=19.99&log=73.78";// + searchInput.value + "&appid=" + appKey;
        $.ajax({
            url: searchLink,
            crossDomain: true,
            success: function (result) {
                alert(result["ApparentTemperature"]);
               
                cityName.innerHTML = result["TimeZone"];
                temperature.innerHTML = result["Temperature"] + "°";
                humidity.innerHTML = result["Humidity"] + "%";
                if (result["Icon"] == "partly-cloudy-night") {
                    $("#weather-icon").removeClass("icon");
                    $("#weather-icon").addClass("partial-cloudy-night");
                }
                else if(result["Icon"]=="cloudy")
                {
                    $("#weather-icon").removeClass("icon");
                    $("#weather-icon").addClass("cloudy-day");
                }
                   // icon.src = "../Images/CompleteLastingHapuka-size_restricted.gif";
            },
            error: function (err) {
                alert("error" + err.responseText + err.status);
            }
        });
    }
}

function theResponse(response) {
    alert(response);
    let jsonObject = JSON.parse(response);
    cityName.innerHTML = jsonObject.name;
    icon.src = "http://openweathermap.org/img/w/" + jsonObject.weather[0].icon + ".png";
    temperature.innerHTML = parseInt(jsonObject.main.temp - 273) + "°";
    humidity.innerHTML = jsonObject.main.humidity + "%";
}

function httpRequestAsync(url, callback) {
    alert("hello");
    $.ajax({
        url: "http://localhost/WeatherForcast.API/api/Values/?lat=19.99&log=73.78",
        "crossDomain": true, success: function (result) {
            alert(result);
        }
    });
   
}

function GetLatLong(city)
{
    alert(city);
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'address': city }, function (results, status) {
        if (status == google.maps.GeocoderStatus.OK) {
            alert("location : " + results[0].geometry.location.lat() + " " + results[0].geometry.location.lng());
        } else {
            alert("Something got wrong " + status);
        }
    });
}